import '@/styles/globals.css';
import localFont from 'next/font/local';

//const noyh = localFont({ src: '../fonts/noyh/Noyh-Light.woff2' })
/*const noyh = localFont({
  src: [
    {
      path: '../fonts/noyh/Noyh-Light.woff2',
      weight: '400',
      style: 'normal',
    },
    {
      path: '../fonts/noyh/Noyh-LightItalic.woff2',
      weight: '400',
      style: 'italic',
    },
    {
      path: '../fonts/noyh/Noyh-Bold.woff2',
      weight: '700',
      style: 'normal',
    },
    {
      path: '../fonts/noyh/Noyh-BoldItalic.woff2',
      weight: '700',
      style: 'italic',
    },
  ],
})*/
import { Open_Sans } from 'next/font/google'
 
// If loading a variable font, you don't need to specify the font weight
const openSans = Open_Sans({ subsets: ['latin'] })


export default function App({ Component, pageProps }) {
  return <div className={openSans.className}>
    <Component {...pageProps} />
  </div>
}
