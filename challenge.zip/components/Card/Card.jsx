import React from 'react';
import styles from './card.module.css';
import Image from 'next/image';
// import glass from '@/public/glass.jpeg'
// import Button from '../Button/Button';
import Info from '../Info/Info';
import Link from 'next/link';

const Card = ({img, categories, name, close, location, price}) => {

  const handleClick = (e) => {
    console.log('Zaza');
  }
  
  return (
    <span className={styles.card} onClick={handleClick}>
      <Image 
        src={img}
        alt='glass'
        width={720}
        height={960}
        className={styles.image}
      />
      <div className={`${styles.description}`}>
        <div className={`${styles.row}`}>
          {categories.map(item => (
            <Info content={item.content} variant={item.variant} />
          ))}
        </div>
        <div className={`${styles.row + ' ' + styles.name}`}><Link href={`/zaza`}><h2>{name}</h2></Link></div>
        <div className={`${styles.row}`}>{close ? 'Fermé' : 'Ouvert'} . {location}</div>
        <div className={`${styles.row}`}>Prix Moyen: FCFA {price}</div>
      </div>
    </span>
  )
}

export default Card