import React from 'react'
import styles from './button.module.css'

const Button = ({content, submit, variant, onClick}) => {
  
  return (
    <input 
      type={submit ? 'submit' : 'button'}
      value={content}
      onClick={(e)=> onClick(e)}
      className={`${styles[variant]} ${styles.button}`}
    />
  )
}

export default Button