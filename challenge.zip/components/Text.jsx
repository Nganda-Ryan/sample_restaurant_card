import React from 'react'

const Text = () => {
  return (
    <span style={{
        height: '200px',
        width: '200px',
        background: 'red'
    }}>Text</span>
  )
}

export default Text