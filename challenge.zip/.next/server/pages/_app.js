/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_font_google_target_css_path_pages_app_js_import_Open_Sans_arguments_subsets_latin_variableName_openSans___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/font/google/target.css?{\"path\":\"pages\\\\_app.js\",\"import\":\"Open_Sans\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"openSans\"} */ \"./node_modules/next/font/google/target.css?{\\\"path\\\":\\\"pages\\\\\\\\_app.js\\\",\\\"import\\\":\\\"Open_Sans\\\",\\\"arguments\\\":[{\\\"subsets\\\":[\\\"latin\\\"]}],\\\"variableName\\\":\\\"openSans\\\"}\");\n/* harmony import */ var next_font_google_target_css_path_pages_app_js_import_Open_Sans_arguments_subsets_latin_variableName_openSans___WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_pages_app_js_import_Open_Sans_arguments_subsets_latin_variableName_openSans___WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n\n\n\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: (next_font_google_target_css_path_pages_app_js_import_Open_Sans_arguments_subsets_latin_variableName_openSans___WEBPACK_IMPORTED_MODULE_2___default().className),\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\user\\\\Desktop\\\\next\\\\challenge\\\\pages\\\\_app.js\",\n            lineNumber: 37,\n            columnNumber: 5\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\user\\\\Desktop\\\\next\\\\challenge\\\\pages\\\\_app.js\",\n        lineNumber: 36,\n        columnNumber: 10\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBK0JNQTtBQS9Cd0I7QUFrQ2YsU0FBU0MsSUFBSSxFQUFFQyxTQUFTLEVBQUVDLFNBQVMsRUFBRTtJQUNsRCxxQkFBTyw4REFBQ0M7UUFBSUMsV0FBV0wsZ0tBQWtCO2tCQUN2Qyw0RUFBQ0U7WUFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7OztBQUU1QiIsInNvdXJjZXMiOlsid2VicGFjazovL2hvdGVsLy4vcGFnZXMvX2FwcC5qcz9lMGFkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnQC9zdHlsZXMvZ2xvYmFscy5jc3MnO1xuaW1wb3J0IGxvY2FsRm9udCBmcm9tICduZXh0L2ZvbnQvbG9jYWwnO1xuXG4vL2NvbnN0IG5veWggPSBsb2NhbEZvbnQoeyBzcmM6ICcuLi9mb250cy9ub3loL05veWgtTGlnaHQud29mZjInIH0pXG4vKmNvbnN0IG5veWggPSBsb2NhbEZvbnQoe1xuICBzcmM6IFtcbiAgICB7XG4gICAgICBwYXRoOiAnLi4vZm9udHMvbm95aC9Ob3loLUxpZ2h0LndvZmYyJyxcbiAgICAgIHdlaWdodDogJzQwMCcsXG4gICAgICBzdHlsZTogJ25vcm1hbCcsXG4gICAgfSxcbiAgICB7XG4gICAgICBwYXRoOiAnLi4vZm9udHMvbm95aC9Ob3loLUxpZ2h0SXRhbGljLndvZmYyJyxcbiAgICAgIHdlaWdodDogJzQwMCcsXG4gICAgICBzdHlsZTogJ2l0YWxpYycsXG4gICAgfSxcbiAgICB7XG4gICAgICBwYXRoOiAnLi4vZm9udHMvbm95aC9Ob3loLUJvbGQud29mZjInLFxuICAgICAgd2VpZ2h0OiAnNzAwJyxcbiAgICAgIHN0eWxlOiAnbm9ybWFsJyxcbiAgICB9LFxuICAgIHtcbiAgICAgIHBhdGg6ICcuLi9mb250cy9ub3loL05veWgtQm9sZEl0YWxpYy53b2ZmMicsXG4gICAgICB3ZWlnaHQ6ICc3MDAnLFxuICAgICAgc3R5bGU6ICdpdGFsaWMnLFxuICAgIH0sXG4gIF0sXG59KSovXG5pbXBvcnQgeyBPcGVuX1NhbnMgfSBmcm9tICduZXh0L2ZvbnQvZ29vZ2xlJ1xuIFxuLy8gSWYgbG9hZGluZyBhIHZhcmlhYmxlIGZvbnQsIHlvdSBkb24ndCBuZWVkIHRvIHNwZWNpZnkgdGhlIGZvbnQgd2VpZ2h0XG5jb25zdCBvcGVuU2FucyA9IE9wZW5fU2Fucyh7IHN1YnNldHM6IFsnbGF0aW4nXSB9KVxuXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pIHtcbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPXtvcGVuU2Fucy5jbGFzc05hbWV9PlxuICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgPC9kaXY+XG59XG4iXSwibmFtZXMiOlsib3BlblNhbnMiLCJBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJkaXYiLCJjbGFzc05hbWUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next"], () => (__webpack_exec__("./pages/_app.js")));
module.exports = __webpack_exports__;

})();